"""택배 QR 토큰: 만들기(택배사 서버)와 검증(로비폰).

형식:  "P1." + base64url( JSON 본문 + Ed25519 서명 64바이트 )
본문 예: {"v":1,"c":"CJ","d":"101","h":"1203","dt":"2026-11-25","w":"09:00-18:00","inv":"1234567890"}
"""
import base64
import datetime as dt
import json
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

PARCEL_PREFIX = "P1."
VISITOR_PREFIX = "V1."
SIG_LEN = 64


class TokenError(Exception):
    """검증 실패. reason은 화면·기록에 그대로 쓰는 한국어 사유."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def b64u_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def b64u_decode(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


# ---------- 키 ----------

def load_private_key(path) -> Ed25519PrivateKey:
    key = serialization.load_pem_private_key(Path(path).read_bytes(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("Ed25519 개인키가 아닙니다")
    return key


def load_trusted_keys(directory) -> dict:
    """허용 택배사 목록: <회사코드>.pub 파일들을 {회사코드: 공개키}로 읽는다."""
    keys = {}
    for path in sorted(Path(directory).glob("*.pub")):
        key = serialization.load_pem_public_key(path.read_bytes())
        if isinstance(key, Ed25519PublicKey):
            keys[path.stem] = key
    return keys


# ---------- 만들기 (택배사 서버) ----------

def make_parcel_token(private_key: Ed25519PrivateKey, company: str, dong: str, ho: str,
                      date: str, window: str, invoice: str) -> str:
    payload = {"v": 1, "c": company, "d": dong, "h": ho,
               "dt": date, "w": window, "inv": invoice}
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    signature = private_key.sign(body)
    return PARCEL_PREFIX + b64u_encode(body + signature)


# ---------- 검증 (로비폰) ----------

def parse_and_verify_parcel(token: str, trusted_keys: dict) -> dict:
    """서명까지 확인한 본문(dict)을 돌려준다. 실패하면 TokenError."""
    if not token.startswith(PARCEL_PREFIX):
        raise TokenError("택배 QR 형식이 아님")
    try:
        raw = b64u_decode(token[len(PARCEL_PREFIX):])
    except Exception:
        raise TokenError("QR 내용을 해석할 수 없음")
    if len(raw) <= SIG_LEN:
        raise TokenError("QR 내용이 너무 짧음")
    body, signature = raw[:-SIG_LEN], raw[-SIG_LEN:]
    try:
        payload = json.loads(body)
    except Exception:
        raise TokenError("QR 내용을 해석할 수 없음")
    if not isinstance(payload, dict):
        raise TokenError("QR 내용을 해석할 수 없음")

    key = trusted_keys.get(payload.get("c"))
    if key is None:
        raise TokenError("등록되지 않은 택배사")
    try:
        key.verify(signature, body)          # 한 글자라도 바뀌면 여기서 실패
    except InvalidSignature:
        raise TokenError("서명 불일치 (위조 의심)")
    return payload


def check_parcel_rules(payload: dict, now: dt.datetime, lobby_dong: str) -> None:
    """동·날짜·시간창 확인. 시각은 Pi 시계(오프라인일 땐 RTC) 기준."""
    if payload.get("d") != lobby_dong:
        raise TokenError(f"다른 동({payload.get('d')}동) 택배")
    if payload.get("dt") != now.date().isoformat():
        raise TokenError("배송 날짜가 아님")
    try:
        start_text, end_text = str(payload.get("w", "")).split("-")
        start = dt.time.fromisoformat(start_text)
        end = dt.time.fromisoformat(end_text)
    except ValueError:
        raise TokenError("시간창 형식 오류")
    if not (start <= now.time() <= end):
        raise TokenError("배송 시간창 밖")


def parcel_key(payload: dict) -> str:
    """1회 사용 판정에 쓰는 키: 회사 + 운송장번호."""
    return f"{payload.get('c')}:{payload.get('inv')}"
