"""로비폰 메인 프로그램.

    python3 -m lobby.main            # 카메라로 계속 QR 읽기
    python3 -m lobby.main --no-gpio  # 부품 없이 화면 출력만

지금 단계: 택배 QR 오프라인 검증 (서명 → 동·날짜·시간창 → 1회 사용) 후 문 개방.
다음 단계: 단지 서버 온라인 조회, 방문자 QR, OLED, 사진 기록.
"""
import argparse
import datetime as dt
import json
import time

from common.tokens import (
    PARCEL_PREFIX,
    VISITOR_PREFIX,
    TokenError,
    check_parcel_rules,
    load_trusted_keys,
    parcel_key,
    parse_and_verify_parcel,
)
from lobby import config
from lobby.hardware import Hardware
from lobby.scanner import iter_qr_codes
from lobby.store import Store


def check_qr(text: str, trusted_keys: dict, store: Store, now: dt.datetime):
    """(허용 여부, 종류, 사유, 본문)을 돌려준다."""
    if text.startswith(PARCEL_PREFIX):
        try:
            payload = parse_and_verify_parcel(text, trusted_keys)
            check_parcel_rules(payload, now, config.LOBBY_DONG)
            key = parcel_key(payload)
            if store.is_used(key):
                raise TokenError("이미 사용된 QR")
            store.mark_used(key)
            return True, "parcel", "택배 QR 확인", payload
        except TokenError as error:
            return False, "parcel", error.reason, None
    if text.startswith(VISITOR_PREFIX):
        return False, "visitor", "방문자 QR은 아직 준비 중", None
    return False, "unknown", "알 수 없는 QR", None


def main() -> None:
    parser = argparse.ArgumentParser(description="로비폰")
    parser.add_argument("--no-gpio", action="store_true", help="부품 없이 화면 출력만")
    parser.add_argument("--camera", choices=["picamera2", "usb"], help="카메라 종류 덮어쓰기")
    args = parser.parse_args()
    if args.no_gpio:
        config.USE_GPIO = False
    camera = args.camera or config.CAMERA

    trusted_keys = load_trusted_keys(config.TRUSTED_KEYS_DIR)
    if not trusted_keys:
        print("[주의] 허용 택배사 공개키가 없습니다. 먼저: python3 -m courier_server.keygen CJ")
    else:
        print(f"허용 택배사: {', '.join(trusted_keys)}")

    hardware = Hardware(config)
    store = Store(config.DB_PATH)
    last_seen = {}

    print(f"{config.LOBBY_DONG}동 로비폰 시작. QR을 카메라에 보여 주세요. (종료: Ctrl+C)")
    try:
        for text, decode_seconds in iter_qr_codes(camera, config.USB_CAMERA_INDEX):
            now_mono = time.monotonic()
            if now_mono - last_seen.get(text, -1e9) < config.SAME_QR_IGNORE_SECONDS:
                continue
            last_seen[text] = now_mono

            hardware.processing()
            allowed, kind, reason, payload = check_qr(
                text, trusted_keys, store, dt.datetime.now())
            detail = json.dumps(payload, ensure_ascii=False) if payload else text[:60]
            store.log(kind, allowed, reason, detail)
            print(f"[{dt.datetime.now():%H:%M:%S}] {'허용' if allowed else '거부'} "
                  f"- {reason} (인식 {decode_seconds:.2f}초)")

            if allowed:
                hardware.show("문이 열립니다", f"{payload['d']}동 {payload['h']}호 택배")
                hardware.allow(config.DOOR_OPEN_SECONDS)
            else:
                hardware.show("출입 거부", reason)
                hardware.reject()
    except KeyboardInterrupt:
        print("\n종료합니다.")


if __name__ == "__main__":
    main()
