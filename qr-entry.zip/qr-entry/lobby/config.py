"""로비폰 설정. 배선이나 모형이 바뀌면 여기만 고친다."""
from pathlib import Path

HERE = Path(__file__).resolve().parent

# 이 로비폰이 설치된 동
LOBBY_DONG = "101"

# 카메라: "picamera2" (CSI 카메라 모듈) 또는 "usb" (USB 웹캠)
CAMERA = "picamera2"
USB_CAMERA_INDEX = 0

# GPIO (BCM 번호). 보고서 2.1 핀 할당표와 같게 유지.
# False면 부품 없이 화면 출력만 한다 (부품 연결 전 테스트용).
USE_GPIO = True
PIN_RELAY = 27
RELAY_ACTIVE_HIGH = True     # 릴레이가 반대로 동작하면 False
PIN_LED_GREEN = 22
PIN_LED_YELLOW = 23
PIN_LED_RED = 24
PIN_BUZZER = 5

DOOR_OPEN_SECONDS = 3        # 문 열림 유지 시간
SAME_QR_IGNORE_SECONDS = 5   # 같은 QR이 연속으로 읽힐 때 무시하는 시간

TRUSTED_KEYS_DIR = HERE / "trusted_keys"   # 허용 택배사 공개키
DB_PATH = HERE / "data" / "lobby.db"       # 출입 기록·사용한 토큰

# 단지 서버 주소. 다음 단계(온라인 검증)에서 사용. None이면 오프라인 검증만.
APT_SERVER_URL = None
