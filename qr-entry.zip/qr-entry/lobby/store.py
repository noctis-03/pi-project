"""로비폰 로컬 저장소 (SQLite): 출입 기록과 사용한 토큰.

오프라인일 때도 '이 로비폰 기준 1회 사용'을 지키고,
연결이 돌아오면 이 기록을 단지 서버와 동기화한다 (다음 단계).
"""
import datetime as dt
import sqlite3
from pathlib import Path


class Store:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS access_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                kind TEXT NOT NULL,          -- parcel / visitor / unknown
                allowed INTEGER NOT NULL,    -- 1 허용, 0 거부
                reason TEXT NOT NULL,
                detail TEXT,
                synced INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS used_tokens (
                key TEXT PRIMARY KEY,
                ts TEXT NOT NULL
            );
        """)
        self.db.commit()

    @staticmethod
    def _now() -> str:
        return dt.datetime.now().isoformat(timespec="seconds")

    def is_used(self, key: str) -> bool:
        row = self.db.execute("SELECT 1 FROM used_tokens WHERE key = ?", (key,)).fetchone()
        return row is not None

    def mark_used(self, key: str) -> None:
        self.db.execute("INSERT OR IGNORE INTO used_tokens (key, ts) VALUES (?, ?)",
                        (key, self._now()))
        self.db.commit()

    def log(self, kind: str, allowed: bool, reason: str, detail: str = "") -> None:
        self.db.execute(
            "INSERT INTO access_log (ts, kind, allowed, reason, detail) VALUES (?, ?, ?, ?, ?)",
            (self._now(), kind, int(allowed), reason, detail))
        self.db.commit()

    def recent(self, limit: int = 20):
        return self.db.execute(
            "SELECT ts, kind, allowed, reason, detail FROM access_log ORDER BY id DESC LIMIT ?",
            (limit,)).fetchall()
