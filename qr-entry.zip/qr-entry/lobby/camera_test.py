"""카메라 QR 인식 테스트 (검증 없이 읽기만).

    python3 -m lobby.camera_test
    python3 -m lobby.camera_test --camera usb

폰 화면·전자종이·종이 QR을 거리별로 보여 주고 인식 시간을 기록해 두세요 (보고서 5.2).
"""
import argparse
import time

from lobby import config
from lobby.scanner import iter_qr_codes


def main() -> None:
    parser = argparse.ArgumentParser(description="카메라 QR 인식 테스트")
    parser.add_argument("--camera", choices=["picamera2", "usb"], default=config.CAMERA)
    args = parser.parse_args()

    print("QR을 카메라에 보여 주세요. (종료: Ctrl+C)")
    last = {}
    try:
        for text, seconds in iter_qr_codes(args.camera, config.USB_CAMERA_INDEX):
            now = time.monotonic()
            if now - last.get(text, -1e9) < 2:
                continue
            last[text] = now
            short = text if len(text) <= 40 else text[:37] + "..."
            print(f"[{time.strftime('%H:%M:%S')}] 인식 {seconds:.2f}초 | {len(text)}자 | {short}")
    except KeyboardInterrupt:
        print("\n종료합니다.")


if __name__ == "__main__":
    main()
