"""문(릴레이)·신호등·부저·안내 문구.

GPIO를 못 쓰는 환경(부품 연결 전, 다른 컴퓨터)에서는 자동으로 화면 출력 모드가 된다.
OLED 안내 문구는 다음 단계에서 show()에 붙인다.
"""
import time


class Hardware:
    def __init__(self, cfg):
        self.mock = not cfg.USE_GPIO
        if not self.mock:
            try:
                from gpiozero import LED, Buzzer, OutputDevice
                self.relay = OutputDevice(cfg.PIN_RELAY, active_high=cfg.RELAY_ACTIVE_HIGH,
                                          initial_value=False)
                self.green = LED(cfg.PIN_LED_GREEN)
                self.yellow = LED(cfg.PIN_LED_YELLOW)
                self.red = LED(cfg.PIN_LED_RED)
                self.buzzer = Buzzer(cfg.PIN_BUZZER)
            except Exception as error:
                print(f"[하드웨어] GPIO를 쓸 수 없어 화면 출력 모드로 실행합니다: {error}")
                self.mock = True

    def show(self, line1: str, line2: str = "") -> None:
        print(f"[안내] {line1}" + (f" / {line2}" if line2 else ""))

    def processing(self) -> None:
        if not self.mock:
            self.yellow.on()

    def allow(self, seconds: float) -> None:
        if self.mock:
            print(f"[문] 열림 ({seconds}초)")
            time.sleep(seconds)
            print("[문] 닫힘")
            return
        self.yellow.off()
        self.green.on()
        self.relay.on()
        time.sleep(seconds)
        self.relay.off()
        self.green.off()

    def reject(self) -> None:
        if self.mock:
            print("[경고] 거부음")
            time.sleep(1)
            return
        self.yellow.off()
        self.red.on()
        for _ in range(2):
            self.buzzer.on()
            time.sleep(0.15)
            self.buzzer.off()
            time.sleep(0.1)
        time.sleep(1.0)
        self.red.off()
