"""카메라에서 QR 문자열을 계속 읽어 내보낸다."""
import time


def iter_qr_codes(camera: str = "picamera2", usb_index: int = 0):
    """(QR 문자열, 인식에 걸린 초)를 끝없이 내보내는 제너레이터."""
    import cv2
    from pyzbar.pyzbar import ZBarSymbol, decode

    if camera == "picamera2":
        from picamera2 import Picamera2
        cam = Picamera2()
        cam.configure(cam.create_preview_configuration(
            main={"size": (1280, 720), "format": "RGB888"}))
        cam.start()
        time.sleep(1.0)                      # 노출이 자리 잡을 시간

        def grab():
            return cam.capture_array()

        def close():
            cam.stop()
            cam.close()
    elif camera == "usb":
        cap = cv2.VideoCapture(usb_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        if not cap.isOpened():
            raise RuntimeError(f"USB 카메라 {usb_index}번을 열 수 없습니다")

        def grab():
            ok, frame = cap.read()
            return frame if ok else None

        def close():
            cap.release()
    else:
        raise ValueError(f"알 수 없는 카메라 설정: {camera}")

    try:
        while True:
            started = time.monotonic()
            frame = grab()
            if frame is None:
                time.sleep(0.05)
                continue
            gray = frame if frame.ndim == 2 else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            for result in decode(gray, symbols=[ZBarSymbol.QRCODE]):
                text = result.data.decode("utf-8", errors="replace")
                yield text, time.monotonic() - started
    finally:
        close()
