"""카메라 없이 택배 QR 문자열을 검증해 본다 (1회 사용 기록은 남기지 않음).

    python3 -m lobby.verify_cli courier_server/out/1234567890.txt
    python3 -m lobby.verify_cli courier_server/out/1234567890.txt --tamper   # 위조 시연
"""
import argparse
import datetime as dt
from pathlib import Path

from common.tokens import (
    PARCEL_PREFIX,
    TokenError,
    b64u_decode,
    b64u_encode,
    check_parcel_rules,
    load_trusted_keys,
    parse_and_verify_parcel,
)
from lobby import config


def tamper(token: str) -> str:
    """본문의 호수 한 글자를 바꾼다 (서명은 그대로) → 서명 불일치가 나와야 정상."""
    raw = bytearray(b64u_decode(token[len(PARCEL_PREFIX):]))
    index = raw.find(b'"h":"') + len(b'"h":"')
    raw[index] = ord("9") if raw[index] != ord("9") else ord("8")
    return PARCEL_PREFIX + b64u_encode(bytes(raw))


def main() -> None:
    parser = argparse.ArgumentParser(description="택배 QR 문자열 검증")
    parser.add_argument("source", help="QR 문자열 또는 .txt 파일 경로")
    parser.add_argument("--tamper", action="store_true", help="호수를 몰래 바꿔서 검증")
    args = parser.parse_args()

    path = Path(args.source)
    token = path.read_text(encoding="utf-8").strip() if path.exists() else args.source.strip()
    if args.tamper:
        token = tamper(token)
        print("※ 호수 한 글자를 바꾼 QR로 검증합니다")

    keys = load_trusted_keys(config.TRUSTED_KEYS_DIR)
    try:
        payload = parse_and_verify_parcel(token, keys)
        print(f"1) 서명 확인: 통과 ({payload['c']})")
        check_parcel_rules(payload, dt.datetime.now(), config.LOBBY_DONG)
        print(f"2) 동·날짜·시간창: 통과 ({payload['d']}동 {payload['h']}호, "
              f"{payload['dt']} {payload['w']})")
        print("결과: 허용")
    except TokenError as error:
        print(f"결과: 거부 - {error.reason}")


if __name__ == "__main__":
    main()
