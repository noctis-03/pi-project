# 비밀번호 없는 공동현관 출입 시스템 (팀 데드락)

라즈베리파이 한 대에서 세 역할을 별도 프로그램으로 실행한다. 실제 구조에서는 각각 다른 장비라고 가정한다.

| 폴더 | 역할 | 실제 구조 |
|---|---|---|
| `lobby/` | 로비폰: QR 인식·검증, 문 제어 | 공동현관 단말 |
| `courier_server/` | 택배사 서버: 택배 QR 서명·발급 (개인키 보관) | 택배회사 서버 |
| `apt_server/` (다음 단계) | 단지 서버: 방문자 QR, 토큰 상태 | 관리사무소 서버 |
| `common/` | QR 토큰 형식·서명·검증 공통 코드 | — |

로비폰은 `lobby/trusted_keys/`의 **공개키만** 읽는다. 택배사 개인키(`courier_server/keys/`)는 로비폰 코드에서 절대 열지 않는다.

## 1. 설치 (Pi에서 한 번)

```
sudo apt update
sudo apt install -y python3-cryptography python3-qrcode python3-pil \
    python3-pyzbar python3-opencv python3-picamera2 python3-gpiozero
```

모든 명령은 이 폴더(`qr-entry`) 안에서 실행한다.

## 2. 첫 테스트 (부품·카메라 없이)

```
python3 -m unittest -v                                   # 자동 테스트 6개 통과 확인
python3 -m courier_server.keygen CJ                      # 택배사 키 만들기 (한 번만)
python3 -m courier_server.issue --dong 101 --ho 1203     # 택배 QR 발급
python3 -m lobby.verify_cli courier_server/out/<운송장번호>.txt            # 허용
python3 -m lobby.verify_cli courier_server/out/<운송장번호>.txt --tamper   # 위조 → 거부
```

## 3. 카메라 테스트

```
python3 -m lobby.camera_test
```

`courier_server/out/*.png`를 다른 화면(PC 모니터·폰)에 띄워 카메라에 보여 준다. 인식 시간이 출력된다.

## 4. 로비폰 실행

```
python3 -m lobby.main --no-gpio   # 부품 없이: 허용/거부가 화면에만 출력
python3 -m lobby.main             # 릴레이·신호등·부저 연결 후
```

시험해 볼 것:
- 정상 QR → 허용, 문 3초 열림
- 같은 QR 다시 → "이미 사용된 QR"
- `--dong 102`로 발급한 QR → "다른 동 택배"
- `--window 06:00-07:00`처럼 지난 시간창 → "배송 시간창 밖"

출입 기록은 `lobby/data/lobby.db`(SQLite)에 쌓인다.

## 핀 (BCM, 보고서 2.1과 동일)

릴레이 27 · 신호등 초록/노랑/빨강 22/23/24 · 부저 5 · PIR 17.
GPIO 18~21은 Fusion HAT+ 오디오와 겹치므로 쓰지 않는다. 핀을 바꾸면 `lobby/config.py`만 고친다.
