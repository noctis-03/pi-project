"""택배 QR 발급 (택배사 서버 역할).

    python3 -m courier_server.issue --dong 101 --ho 1203
    python3 -m courier_server.issue --dong 101 --ho 1203 --window 09:00-18:00 --date 2026-11-25

결과: courier_server/out/<운송장번호>.png (QR 이미지) 와 .txt (QR 문자열)
"""
import argparse
import datetime as dt
import random
import sys
from pathlib import Path

from common.tokens import load_private_key, make_parcel_token

ROOT = Path(__file__).resolve().parent.parent
KEYS_DIR = ROOT / "courier_server" / "keys"
OUT_DIR = ROOT / "courier_server" / "out"


def main() -> None:
    parser = argparse.ArgumentParser(description="서명된 택배 QR 만들기")
    parser.add_argument("--company", default="CJ", help="택배사 코드 (기본 CJ)")
    parser.add_argument("--dong", required=True, help="동 (예: 101)")
    parser.add_argument("--ho", required=True, help="호수 (예: 1203)")
    parser.add_argument("--date", default=dt.date.today().isoformat(),
                        help="배송 날짜 YYYY-MM-DD (기본 오늘)")
    parser.add_argument("--window", default="00:00-23:59",
                        help="배송 시간창 HH:MM-HH:MM (기본 하루 종일)")
    parser.add_argument("--invoice", help="운송장번호 (기본 무작위 10자리)")
    parser.add_argument("--ascii", action="store_true", help="터미널에도 QR 출력")
    args = parser.parse_args()

    private_path = KEYS_DIR / f"{args.company}.pem"
    if not private_path.exists():
        sys.exit(f"{args.company} 개인키가 없습니다. 먼저 실행: "
                 f"python3 -m courier_server.keygen {args.company}")

    invoice = args.invoice or "".join(random.choices("0123456789", k=10))
    token = make_parcel_token(load_private_key(private_path), args.company,
                              args.dong, args.ho, args.date, args.window, invoice)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUT_DIR / f"{invoice}.txt").write_text(token + "\n", encoding="utf-8")

    import qrcode
    from qrcode.constants import ERROR_CORRECT_M
    qr = qrcode.QRCode(error_correction=ERROR_CORRECT_M, box_size=10, border=4)
    qr.add_data(token)
    qr.make(fit=True)
    qr.make_image().save(OUT_DIR / f"{invoice}.png")

    print(f"택배 QR 발급: {args.company} {args.dong}동 {args.ho}호, "
          f"{args.date} {args.window}, 운송장 {invoice}")
    print(f"QR 버전 {qr.version}, 문자열 {len(token)}자")
    print(f"이미지: {OUT_DIR / (invoice + '.png')}")
    print(f"문자열: {token}")
    if args.ascii:
        qr.print_ascii(invert=True)


if __name__ == "__main__":
    main()
