"""택배사 키 만들기.

    python3 -m courier_server.keygen CJ

- 개인키: courier_server/keys/CJ.pem   (택배사 서버만 가짐. 절대 공유 금지)
- 공개키: lobby/trusted_keys/CJ.pub    (로비폰의 '허용 택배사 목록'에 등록)
"""
import argparse
import os
import sys
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

ROOT = Path(__file__).resolve().parent.parent
KEYS_DIR = ROOT / "courier_server" / "keys"
TRUSTED_DIR = ROOT / "lobby" / "trusted_keys"


def main() -> None:
    parser = argparse.ArgumentParser(description="택배사 Ed25519 키 만들기")
    parser.add_argument("company", help="택배사 코드 (영문, 예: CJ)")
    parser.add_argument("--force", action="store_true", help="이미 있으면 덮어쓰기")
    args = parser.parse_args()

    company = args.company.strip()
    if not company.isalnum():
        sys.exit("택배사 코드는 영문·숫자만 쓰세요 (예: CJ)")

    KEYS_DIR.mkdir(parents=True, exist_ok=True)
    TRUSTED_DIR.mkdir(parents=True, exist_ok=True)
    private_path = KEYS_DIR / f"{company}.pem"
    public_path = TRUSTED_DIR / f"{company}.pub"
    if private_path.exists() and not args.force:
        sys.exit(f"이미 키가 있습니다: {private_path}  (새로 만들려면 --force)")

    private_key = Ed25519PrivateKey.generate()
    private_path.write_bytes(private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    ))
    os.chmod(private_path, 0o600)
    public_path.write_bytes(private_key.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    ))

    print(f"개인키 저장: {private_path}")
    print(f"공개키 등록: {public_path}")


if __name__ == "__main__":
    main()
