"""토큰 서명·검증 테스트.   python3 -m unittest -v"""
import datetime as dt
import unittest

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from common.tokens import (
    TokenError,
    b64u_encode,
    check_parcel_rules,
    make_parcel_token,
    parse_and_verify_parcel,
)
from lobby.verify_cli import tamper

NOW = dt.datetime(2026, 11, 25, 10, 0)


class ParcelTokenTest(unittest.TestCase):
    def setUp(self):
        self.key = Ed25519PrivateKey.generate()
        self.trusted = {"CJ": self.key.public_key()}
        self.token = make_parcel_token(self.key, "CJ", "101", "1203",
                                       "2026-11-25", "09:00-18:00", "1234567890")

    def assertRejected(self, func, reason):
        with self.assertRaises(TokenError) as ctx:
            func()
        self.assertEqual(ctx.exception.reason, reason)

    def test_valid_token_passes(self):
        payload = parse_and_verify_parcel(self.token, self.trusted)
        check_parcel_rules(payload, NOW, "101")
        self.assertEqual(payload["h"], "1203")

    def test_tampered_token_rejected(self):
        self.assertRejected(lambda: parse_and_verify_parcel(tamper(self.token), self.trusted),
                            "서명 불일치 (위조 의심)")

    def test_unknown_company_rejected(self):
        other = Ed25519PrivateKey.generate()
        token = make_parcel_token(other, "XX", "101", "1203", "2026-11-25",
                                  "09:00-18:00", "1")
        self.assertRejected(lambda: parse_and_verify_parcel(token, self.trusted),
                            "등록되지 않은 택배사")

    def test_forged_with_other_key_rejected(self):
        other = Ed25519PrivateKey.generate()
        token = make_parcel_token(other, "CJ", "101", "1203", "2026-11-25",
                                  "09:00-18:00", "1")
        self.assertRejected(lambda: parse_and_verify_parcel(token, self.trusted),
                            "서명 불일치 (위조 의심)")

    def test_rules(self):
        payload = parse_and_verify_parcel(self.token, self.trusted)
        self.assertRejected(lambda: check_parcel_rules(payload, NOW, "102"),
                            "다른 동(101동) 택배")
        self.assertRejected(lambda: check_parcel_rules(payload, NOW + dt.timedelta(days=1), "101"),
                            "배송 날짜가 아님")
        self.assertRejected(lambda: check_parcel_rules(payload, NOW.replace(hour=19), "101"),
                            "배송 시간창 밖")

    def test_garbage_rejected(self):
        self.assertRejected(lambda: parse_and_verify_parcel("P1.AAAA", self.trusted),
                            "QR 내용이 너무 짧음")
        junk = "P1." + b64u_encode(b"x" * 100)
        self.assertRejected(lambda: parse_and_verify_parcel(junk, self.trusted),
                            "QR 내용을 해석할 수 없음")


if __name__ == "__main__":
    unittest.main()
